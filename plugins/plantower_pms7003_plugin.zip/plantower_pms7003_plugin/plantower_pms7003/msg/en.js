Blockly.Msg.plantower_pms7003_GET_PM2_5_TEXT_TITLE   = "PMS7003 PM2.5";
Blockly.Msg.plantower_pms7003_GET_PM2_5_TEXT_TOOLTIP = "pms7003 get pm2.5";
Blockly.Msg.plantower_pms7003_GET_PM2_5_TEXT_HELPURL = "";

Blockly.Msg.plantower_pms7003_GET_PM10_TEXT_TITLE   = "PMS7003 PM10";
Blockly.Msg.plantower_pms7003_GET_PM10_TEXT_TOOLTIP = "pms7003 get pm10";
Blockly.Msg.plantower_pms7003_GET_PM10_TEXT_HELPURL = "";