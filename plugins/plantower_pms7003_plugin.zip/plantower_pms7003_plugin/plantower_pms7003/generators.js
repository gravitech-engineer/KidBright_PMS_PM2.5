Blockly.JavaScript['plantower_pms7003.getpm2_5'] = function(block) {
	return [
		'DEV_IO.plantower_pms7003().get_pm2_5()',
		Blockly.JavaScript.ORDER_ATOMIC
	];
};

Blockly.JavaScript['plantower_pms7003.getpm10'] = function(block) {
	return [
		'DEV_IO.plantower_pms7003().get_pm10()',
		Blockly.JavaScript.ORDER_ATOMIC
	];
};
